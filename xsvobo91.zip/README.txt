****************** INSTALLATION *****************

Nainstalujte knihovnu OGDF www.ogdf.net
Nastavte cestu ke knihovn� OGDF v souboru gal.config

gcc Compiler (Linux, Mac OS):

 A) Pomoc� aplikace Qt Creator

 B) Pomoc� qmake
  1. Ve slo�ce aplikace spust�me qmake pro vygenerov�n� Makefile
	qmake GAL.pro

  2. Pomoc� make sestav�me aplikaci

Visual Studio (Windows):

  1. Nainstalujte dopln�k Visual Studio Add-in 1.2.4 for Qt5

  2. Otev�ete projekt pomoc� GAL.pro a sestavte.